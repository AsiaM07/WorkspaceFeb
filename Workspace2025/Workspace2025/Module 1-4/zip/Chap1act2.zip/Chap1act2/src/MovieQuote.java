//Asia M 2/3 Chap1act2

public class MovieQuote {

	public static void main(String[] args) {
		System.out.println("The Menu");
		System.out.println("I said, I don't like your food, and I would like to send it back.");
		System.out.println("Margot");
		System.out.println("Year 2022");

	}

}
