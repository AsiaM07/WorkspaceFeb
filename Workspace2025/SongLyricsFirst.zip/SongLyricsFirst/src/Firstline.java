//Asia M 2/1 Chap1Act1

public class Firstline {

	public static void main(String[] args) {
		System.out.println("Make it to the high fashion");
		System.out.println("Make it to the high fashion");
		System.out.println("Make it to the high fashion");
		
	}

}
